const io = require('socket.io')(8000)

const user = {};

io.on('connection', socket => {
    socket.on('new-user-name', name => {
        user[socket.id] = name;
        socket.broadcast.emit('user joind', name);
    });
    socket.on('send', message => {

        socket.broadcast.emit('received', {
            message: message, name: user[socket.id]
        });
    })
})
