const express = require('express');
const app = express();
const http = require('http');
const socketio = require('socket.io')
const server = http.createServer(app);

app.get('/', (req, res) => {
    var get_data = 
    res.send('<h1>Hello world</h1>');
});
app.get('/about', (req, res) => {
    res.send('we are learning node.js');
})

server.listen(5000, () => {
    console.log('listening on *:5000');
});