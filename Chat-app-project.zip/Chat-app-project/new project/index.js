const express = require('express');
const application = express();
const http = require('http');
const server = http.createServer(application);
const { Server } = require('socket.io');
const io = new Server(server);

application.get('/', (req, res) => {
    res.send( '/index.html')
});

io.on('connection', (socket) => {
    console.log('User is connected');
    socket.on('disconnect', function () {
        console.log('User is disconnected')
    });
    socket.on('chat message', (msg) => {
        io.emit('chat message', msg);
    });
});


server.listen(5000, function () {
    console.log('server has connected in 5000 port')
});